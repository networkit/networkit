#!/bin/bash

wget https://networkit.iti.kit.edu/data/uploads/docs/Notebooks/ae-summer-school-tutorial-1.ipynb
wget https://networkit.iti.kit.edu/data/uploads/docs/Notebooks/ae-summer-school-tutorial-2.ipynb
wget https://networkit.iti.kit.edu/data/uploads/docs/Notebooks/ae-summer-school-tutorial-3.ipynb
wget https://networkit.iti.kit.edu/data/uploads/docs/Notebooks/ae-summer-school-tutorial-4.ipynb
mv ae-summer-* Doc/Notebooks

wget https://networkit.iti.kit.edu/data/uploads/docs/Notebooks/airfoil1-10p.png
wget https://networkit.iti.kit.edu/data/uploads/docs/Notebooks/mit8.edgelist.gz
mkdir input-tutorial
mv airfoil1-10p.png input-tutorial
gunzip mit8.edgelist.gz
mv mit8.edgelist input-tutorial
